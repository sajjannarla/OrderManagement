This REST service is developed by using Gin framework

This repository has two files, one is order process file and another one is test file. Order process file has all the methods which will process the orders based on user action and test file has corresponding test functions

No database is used here, data is readonly and added manuall in main.go file 

Output of the methods looks like below :

> Get all orders 

[
{
"id": 1,
"date": "2022-01-27T20:49:26.4012008Z",
"value": 56.99,
"status": "New",
"storeid": {
"storeid": "ASL",
"name": "AllSaintsLondon"
}
},
{
"id": 2,
"date": "2022-01-27T20:49:26.4012008Z",
"value": 70.99,
"status": "Cancelled",
"storeid": {
"storeid": "ASM",
"name": "AllSaintsManchester"
}
},
{
"id": 3,
"date": "2022-01-27T20:49:26.4012008Z",
"value": 80.5,
"status": "Shipped",
"storeid": {
"storeid": "ASB",
"name": "AllSaintsBirmingham"
}
}
]

> Get order by ID 

{
"id": 1,
"date": "2022-01-27T20:49:26.4012008Z",
"value": 56.99,
"status": "New",
"storeid": {
"storeid": "ASL",
"name": "AllSaintsLondon"
}
}