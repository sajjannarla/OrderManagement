package handlers

import (
	"bytes"
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestGetOrders(t *testing.T) {
	req, err := http.NewRequest("GET", "/entries", nil)
	if err != nil {
		t.Fatal(err)
	}
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(GetOrders)

	handler.ServeHTTP(rr, req)
	if status := rr.Code; status != http.StatusOK {
		t.Errorf("handler returned wrong status code: got %v want %v",
			status, http.StatusOK)
	}

	// Check the response body is what we expect.
	expected := `[{ID: 1, Date: 2022-01-27T16:12:51.7583651Z, Value 56.99, Status: New, Stores: Stores{ID: "ASL", Name: "AllSaintsLondon"}},{ID: 2, Date: 2022-01-27T16:12:51.7583651Z, Value: 70.99, Status: Cancelled, Stores: Stores{ID: "ASM", Name: "AllSaintsManchester"}},{ID: 3, Date: 2022-01-27T16:12:51.7583651Z, Value: 80.50, Status: Shipped, Stores: Stores{ID: "ASB", Name: "AllSaintsBirmingham"}}]`
	if rr.Body.String() != expected {
		t.Errorf("handler returned unexpected body: got %v want %v",
			rr.Body.String(), expected)
	}
}

func TestGetOrderByID(t *testing.T) {

	req, err := http.NewRequest("GET", "/entry", nil)
	if err != nil {
		t.Fatal(err)
	}
	q := req.URL.Query()
	q.Add("id", "1")
	req.URL.RawQuery = q.Encode()
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(GetOrderByID)
	handler.ServeHTTP(rr, req)
	if status := rr.Code; status != http.StatusOK {
		t.Errorf("handler returned wrong status code: got %v want %v",
			status, http.StatusOK)
	}

	// Check the response body is what we expect.
	expected := `{ID: 1, Date: 2022-01-27T16:12:51.7583651Z, Value:56.99, Status: New, Stores: Stores{ID: "ASL", Name: "AllSaintsLondon"}}`
	if rr.Body.String() != expected {
		t.Errorf("handler returned unexpected body: got %v want %v",
			rr.Body.String(), expected)
	}
}

func TestCreateEntry(t *testing.T) {

	var jsonStr = []byte(`{ID: 4, Date: 2022-01-27T16:12:51.7583651Z, Value: 75, Status: New, Stores: Stores{ID: "ASB", Name: "AllSaintsBlackpool"}}`)

	req, err := http.NewRequest("POST", "/entry", bytes.NewBuffer(jsonStr))
	if err != nil {
		t.Fatal(err)
	}
	req.Header.Set("Content-Type", "application/json")
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(CreateOrder)
	handler.ServeHTTP(rr, req)
	if status := rr.Code; status != http.StatusOK {
		t.Errorf("handler returned wrong status code: got %v want %v",
			status, http.StatusOK)
	}
	expected := `{ID: 4, Date: 2022-01-27T16:12:51.7583651Z, Value: 75, Status: New, Stores: Stores{ID: "ASB", Name: "AllSaintsBlackpool"}}`
	if rr.Body.String() != expected {
		t.Errorf("handler returned unexpected body: got %v want %v",
			rr.Body.String(), expected)
	}
}

func TestCancelOrder(t *testing.T) {
	req, err := http.NewRequest("DELETE", "/entry", nil)
	if err != nil {
		t.Fatal(err)
	}
	q := req.URL.Query()
	q.Add("id", "3")
	req.URL.RawQuery = q.Encode()
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(CancelOrder)
	handler.ServeHTTP(rr, req)
	if status := rr.Code; status != http.StatusOK {
		t.Errorf("handler returned wrong status code: got %v want %v",
			status, http.StatusOK)
	}
	expected := `{ID: 3, Date: time.Now(), Value: 80.50, Status: Shipped, Stores: Stores{ID: "ASB", Name: "AllSaintsBirmingham"}}`
	if rr.Body.String() != expected {
		t.Errorf("handler returned unexpected body: got %v want %v",
			rr.Body.String(), expected)
	}
}
