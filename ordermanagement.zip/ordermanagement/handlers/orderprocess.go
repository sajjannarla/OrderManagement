package handlers

import (
	"net/http"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
)

// OrderStatus represents the status
type OrderStatus string

// OrderStatus
const (
	New       OrderStatus = "New"
	Cancelled             = "Cancelled"
	Shipped               = "Shipped"
)

// Order represents data about an order.
type Order struct {
	ID     int32       `json:"id"`
	Date   time.Time   `json:"date"`
	Value  float32     `json:"value"`
	Status OrderStatus `json:"status"`
	Stores Stores      `json:"storeid"`
}

//Stores represents data about store
type Stores struct {
	ID   string `json:"storeid"`
	Name string `json:"name"`
}

// Orders slice to seed record order data.
var Orders = []Order{
	{ID: 1, Date: time.Now(), Value: 56.99, Status: New, Stores: Stores{ID: "ASL", Name: "AllSaintsLondon"}},
	{ID: 2, Date: time.Now(), Value: 70.99, Status: Cancelled, Stores: Stores{ID: "ASM", Name: "AllSaintsManchester"}},
	{ID: 3, Date: time.Now(), Value: 80.50, Status: Shipped, Stores: Stores{ID: "ASB", Name: "AllSaintsBirmingham"}},
}

// GetOrders responds with the list of all orders as JSON.
func GetOrders(c *gin.Context) {
	c.IndentedJSON(http.StatusOK, Orders)
}

// CreateOrder adds an order from JSON received in the request body
func CreateOrder(c *gin.Context) {
	var newOrder Order

	if err := c.BindJSON(&newOrder); err != nil {
		return
	}

	// Add the new order to the slice.
	Orders = append(Orders, newOrder)
	c.IndentedJSON(http.StatusCreated, newOrder)
}

// GetOrderByID locates the order whose ID value matches the id
// parameter sent by the user, then returns that order as a response.
func GetOrderByID(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	for _, a := range Orders {
		if a.ID == int32(id) {
			c.IndentedJSON(http.StatusOK, a)
			return
		}
	}
	c.IndentedJSON(http.StatusNotFound, gin.H{"message": "order not found"})
}

// CancelOrder cancels the order
func CancelOrder(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	for index, a := range Orders {
		if a.ID == int32(id) {
			Orders = append(Orders[:index], Orders[index+1:]...)
			return
		}
	}
}
