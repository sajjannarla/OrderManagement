package main

import (
	orderprocess "Order-Management/web-service-gin/handlers"

	"github.com/gin-gonic/gin"
)

func main() {
	router := gin.Default()
	router.GET("/orders", orderprocess.GetOrders)
	router.GET("/orders/:id", orderprocess.GetOrderByID)
	router.POST("/orders", orderprocess.CreateOrder)
	router.DELETE("/orders/delete/:id", orderprocess.CancelOrder)

	router.Run("localhost:8080")
}
